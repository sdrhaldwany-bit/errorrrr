CREATE TABLE "devices" (
	"id" text PRIMARY KEY,
	"kind" text DEFAULT 'termux' NOT NULL,
	"info" text DEFAULT '' NOT NULL,
	"last_seen" timestamp DEFAULT now(),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "jobs" (
	"id" serial PRIMARY KEY,
	"device_id" text NOT NULL,
	"command" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"output" text DEFAULT '' NOT NULL,
	"exit_code" integer,
	"created_at" timestamp DEFAULT now(),
	"finished_at" timestamp
);
--> statement-breakpoint
CREATE INDEX "jobs_device_status_idx" ON "jobs" ("device_id","status");--> statement-breakpoint
ALTER TABLE "jobs" ADD CONSTRAINT "jobs_device_id_devices_id_fkey" FOREIGN KEY ("device_id") REFERENCES "devices"("id") ON DELETE CASCADE;